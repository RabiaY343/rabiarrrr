﻿using Microsoft.AspNetCore.Mvc;
using WebApplication1.Models;

namespace WebApplication1.Controllers
{
    public class Products : Controller
    {
        NorthwindContext db = new NorthwindContext();
        public IActionResult Listele()
        {
            var result = db.Products.ToList();

            return View(result);
        }

        public IActionResult TekKayitGetir()
        {
            return View();
        }

        
        public IActionResult TekKayitGetir2(int id)
        {
            var result = db.Products.Find(id);
            return View(result);
        }

        
        public IActionResult Ekle()
        {
            return View();
        }

        [HttpPost] 
        public IActionResult Ekle2(Category k)
        {
            db.Products.Add(k); 

            db.SaveChanges();

            return View("Listele", db.Categories.ToList());
            
        }
        public IActionResult Guncelle(int id)
        {
            return View(db.Categories.Find(id));
        }

        
        [HttpPost]
        public IActionResult Guncelle(Category c)
        {
            var data = db.Products.FirstOrDefault(x => x.CategoryId == c.CategoryId);

            if (data is not null)
            {
                data.ProductName = c.CategoryName;
                data.Description = c.Description;

                db.SaveChanges();

                return RedirectToAction("Listele");
            }

            ViewBag.UpdateError = "Hata";
            return View();
        }

        public IActionResult Sil(int id)
        {
           
            var data3 = db.Products.FirstOrDefault(x => x.CategoryId == id);

            db.Products.Remove(data3!);

            db.SaveChanges();

            return RedirectToAction("Listele");
        }
    }
}
