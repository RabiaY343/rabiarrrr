﻿using System;
using System.Collections.Generic;

namespace WebApplication1.Models;

public partial class Student
{
    public int Id { get; set; }
}
